# basketball-player-detection > 2025-07-04 8:04am
https://universe.roboflow.com/bees-uafex/basketball-player-detection-0pgs1

Provided by a Roboflow user
License: CC BY 4.0

